THE PINK CODE V6 - INSTALLATION

Game: site/index.html
Organizer: site/admin.html
Current game URL: https://extraordinary-platypus-fa323b.netlify.app/
Current organizer URL: https://extraordinary-platypus-fa323b.netlify.app/admin.html

IMPORTANT: The game can be tested locally but shared questions and leaderboard require a full Netlify Git deployment with the Netlify Function and Blobs, plus environment variable PINK_ADMIN_SECRET (at least 16 characters). Do not upload only the site directory if you need live editing.

QR_JOUEURS.png and QR_ORGANISATEUR.png point to the current URLs, not to newly deployed V6 until you publish it.

See MANUEL_V6.pdf for detailed instructions.
